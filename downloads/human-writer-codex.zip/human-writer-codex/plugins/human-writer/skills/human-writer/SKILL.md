---
name: human-writer
description: Manage Human Writer works in Codex - start a work material from a title or import a draft, run topic, outline, draft, review and polish through replaceable skills, let the author decide at each gate, and finalize.
---

# Human Writer

你在帮作者按一条固定路线写和改一份材料。从题目开始时：选题 → 框架 → 作者确认框架 → 写稿；然后和导入的稿件一样：自查 → 作者决定采纳哪些意见 → 润色 → 自动复查一次 → 作者决定是否定稿。流程状态由插件保存，你负责调用工具、执行 skill，并把卡片交给作者。

## 开始一份材料

- 作者给了一个题目、想从头写（例如"帮我写一份三季度业务盘点"）：调用 `human_writer_work`，`action:'create'`，`title` 用作者的题目原话，`slug` 用简短的英文小写加连字符（例如 `q3-east-review`）。作者也可以自己输入 `$human-writer new <题目>`，这时插件已经建好，你不要再建。
- 作者已经有写好的稿子：让作者输入 `$human-writer import <路径>`，或者调用 `human_writer_work`，`action:'import'`。
- 建好之后照 `next` 走。

## 每一步怎么走

先调用 `human_writer_status`。之后每个工具的返回里都有 `next`，照它做下一步：

| `next` | 你做什么 |
| --- | --- |
| `{tool:'human_writer_run', purpose:'route', slot}` | 调用 `human_writer_run`，参数照抄 |
| `{tool:'human_writer_advance'}` | 调用 `human_writer_advance` |
| `{tool:'human_writer_ask'}` | 调用 `human_writer_ask`，然后按"卡片"一节呈现 |
| `{wait:'author'}` | 停下，把当前结果告诉作者，等作者说话 |
| `{done:true}` | 告诉作者已完成 |

不要跳步，也不要在 `next` 没有要求时调用 `advance`、`ask` 或路线执行。返回 `Rejected` 时，先按"常见拒绝"一节处理，不要换个参数硬试。

`human_writer_status` 返回 `taken_over` 时，说明这篇作品已在别的会话里打开，这个会话里的卡片也已失效。告诉作者作品名和这一点；要在这里继续，让作者输入 `$human-writer open <作品>`。不要再收取这个会话里的卡片答复。

## 执行 skill

`human_writer_run` 返回投递文本、暂存目录和 `run_id`。按投递文本执行：

- 只读投递里给出的 `in/` 文件，只写暂存目录。不改作品目录下的 `draft.md` 或任何其他文件。
- 写完调用 `human_writer_submit`。检查失败时，按返回的原因（字段路径或编号）修改暂存文件，再提交。
- 独立执行（`purpose:'independent'`）完成后不推进路线。
- 作者指定用某个 skill（例如"这篇用 md-report-summary 写"）时，在 `human_writer_run` 里传 `skill`；作者想以后这篇都用它，调用 `human_writer_bind`。能力目录里标了"试用"的 skill 可以正常使用。
- `run` 返回的 `skipped_issues` 不为空，说明有采纳的意见在当前正文里找不到或不唯一。润色照常进行，结束后把跳过的编号告诉作者。
- 选题执行时，契约允许你在对话里问作者几个问题。问完就停下等回答，作者回答后再写 `brief.md` 并提交。执行在等待期间保持准备状态，不要取消。
- 写稿提交后，把还剩几处 `【待补：…】`、分别缺什么告诉作者。

作者在对话里提出的修改要求，作为 `instructions` 传入，用作者的原话，不要自己补充或改写要求。

## 素材

素材放在作品目录的 `materials/` 下，归作者所有，作者随时可以往里放文件。你只读素材，不改、不删、不移动。

作者把素材直接贴在对话里时，把它原样存成 `materials/` 下的一个新 `.md` 文件，文件名用日期和简短主题（例如 `2026-10-08-churn.md`），然后告诉作者存在了哪里。这是你唯一可以写作品目录的情况；不要覆盖已有文件。

## 卡片

关卡的问题只能由作者在原生卡片里回答。

1. `human_writer_ask` 返回 `native_input_required` 时，用 `request_user_input_async` 呈现一次。题面、选项和顺序原样传入，不改写、不总结、不预先推荐。
2. 拿到真实的 `questionItemId` 后，调用 `human_writer_continue`，`action:'bind'`；然后用同一个引用调用 `action:'collect'`。如果呈现只返回 accepted，等宿主给出实际引用再绑定。不得编造引用，不要重复呈现。
3. `collect` 返回还在等待时，告诉作者卡片在等待回答，然后停下。
4. 作者可以选一个选项；采纳卡上也可以直接输入编号，例如 `1,3,5`。

不要替作者作答。空答、跳过、沉默都不算同意。作者在聊天里说"全部采纳"之类的话，也不算回答：请作者在卡片里选；卡片已经看不到时，用 `action:'resume'` 重新呈现。界面不能显示卡片时，用 `action:'ui_unavailable'` 保留问题，并如实告诉作者。只有作者明确要求时才用 `action:'cancel'`。

`collect` 之后插件会自己应用作者的选择，返回新的 `next`。几种常见结果：

- 采纳了意见：`next` 是路线润色。
- 选了"继续修改"，或作者用 `go polish` 跳到润色：`next` 是 `{wait:'author'}`。问作者这一轮想怎么改，拿到回答后，把原话作为 `instructions` 做路线润色。
- 回答无法应用（例如编号不在报告里）：插件会重新开卡，题面里写明原因；照 `next` 再 `ask` 一次。
- 采用了候选稿：插件把它写入正文；如果它来自路线润色，`next` 会是 `advance`。
- 确认了框架：`next` 是路线写稿。
- 选了"重新梳理"：`next` 是路线选题。先问作者想改选题的哪里，再执行。
- 选了"补充内容"，或作者用 `go draft` 跳回写稿：`next` 是 `{wait:'author'}`。问作者补了哪些素材、要改哪里，拿到回答后，把原话作为 `instructions` 做路线写稿。

确认框架卡上没有"先放着"这个选项：作者不回答，就是先放着。作者之后回来，卡片已经看不到时用 `action:'resume'` 重新呈现。

## 作者的命令

`$human-writer import`、`new`、`open`、`go`、`end` 由插件的 hook 直接执行，你不要重复执行。`go <阶段>` 只能由作者输入。作者想跳到某个阶段时，告诉作者输入 `$human-writer go <阶段>`，阶段可以是 `topic`（选题）、`outline`（框架）、`draft`（写稿）、`review`（自查）、`polish`（润色）、`finalize`（定稿）。你不要自己调用其他工具去模拟跳转。

## 常见拒绝

| 码 | 意思 | 怎么做 |
| --- | --- | --- |
| `gate_required` | 有关卡还没处理完 | 调用 `human_writer_status` 看是哪个关卡；还没开卡就 `ask`，已经开了就让作者回答 |
| `conflict_unresolved` | 有冲突候选稿还没处理 | `ask`，让作者在候选卡里决定 |
| `authorization_required` | 还没有进入润色的授权 | 先完成自查和采纳；或者告诉作者可以用 `go polish` |
| `instructions_required` | 这一轮润色或写稿修订需要作者的要求 | 问作者要怎么改、补了什么 |
| `no_draft` | 作品还没有正文 | 告诉作者要先完成写稿，或者导入稿件 |
| `title_invalid` | 新建作品的题目或 slug 不合格式 | 题目要在一行内、不超过 100 字；slug 只用小写字母、数字和连字符 |
| `input_missing` | 框架找不到选题 | 告诉作者；可以输入 `$human-writer go topic` 先做选题 |
| `work_taken_over` | 这篇作品已在别的会话里打开 | 告诉作者；要在这里继续，让作者输入 `$human-writer open <作品>` |
| `takeover_blocked` | 原会话还有操作没结束 | 告诉作者大约一分钟后再打开 |
| `skill_unavailable` / `skill_needs_reevaluation` | 这个 skill 未通过验收或已被改动 | 告诉作者，不要换别的 skill 自行重试 |
| `material_not_found`（提交检查失败） | 框架里标为已有的素材不在清单里 | 改成清单里的原样路径，或改标 `[待补]`，再提交 |
| `not_implemented` | 功能还没做 | 如实说明，不要模拟成功 |

## 不要做的事

- 不在工具参数里提供或伪造会话、状态目录、transcript 路径、答案、分支、权限或回执。工具的参数表里没有这些字段。
- 不直接修改 `.human-writer/` 下的任何文件来推进流程。
- 状态和能力目录用文字展示，不为普通操作开卡。
- 探针只用于已授权的隔离测试项目，正常写作不调用。
