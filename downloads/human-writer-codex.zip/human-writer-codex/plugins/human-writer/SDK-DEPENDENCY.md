# SDK dependency

Task State SDK 0.5.0，源提交 `5cce5bae103ab194b2b94ed58aecf0a2ccb84c80`。

完整锁见 `sdk-dependency.json`。快照从 reviewer-plugin `63d27dc` 的 vendor 原样复制，字节不改；每个进程只加载一份。hook 和 MCP 共用状态根。

升级：当前不跟随上游。

校验：在仓库根运行 `node tools/verify-human-writer-sdk.mjs`，以及 `node plugins/human-writer/vendor/task-state-sdk/scripts/sdk-contracts.mjs`。
