# SDK dependency

Task State SDK 0.5.0，源提交 `5cce5bae103ab194b2b94ed58aecf0a2ccb84c80`。

完整锁见 `sdk-dependency.json`。基线从 reviewer-plugin `63d27dc` 的 vendor 原样复制；每个进程只加载一份。hook 和 MCP 共用状态根。

2026-10-12 经 David 明确允许，制作维护快照 `hw-native-reply-whitespace-20261012`：只回移上游 `5fbf9e3c555e28772dcb48d34a4e7f47f9254795` 的原生回复外层空白修复。运行代码仅 `sdk/adapters/codex-proof.mjs` 一行变化，该文件与上游修复提交逐字节一致；未引入 Devin 适配。`sourceCommit` 仍表示 0.5.0 基线，不声称是未经修改的上游快照；锁与 manifest 的 `maintenance` 记录补丁来源及前后哈希。SDK 其他文件（含版本文件、校验器）保持原字节，Matt 仓库未修改。

升级：当前不跟随上游。维护快照不能被无记录的本地补丁替代；后续正式升级仍须核对完整差异。

校验：在仓库根运行 `node tools/verify-human-writer-sdk.mjs`，以及 `node plugins/human-writer/vendor/task-state-sdk/scripts/sdk-contracts.mjs`。
