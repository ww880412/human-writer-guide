# 适配说明：material-draft 用于 draft 槽位

适配的 skill 正文：Human Writer 本地 skill `material-draft` 的 `SKILL.md`，由 Claude 撰写，专为写稿槽位写成。如果契约和本说明与 skill 正文冲突，以契约为准，其次以本说明为准。

skill 正文写的是方法；输入从哪里读、产出写成什么格式、写到哪里、什么时候提交，都按契约。skill 正文里没有与契约冲突的交付方式，不需要替换。
