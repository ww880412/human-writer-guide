# 适配说明：product-check 用于 product-review 槽位

适配的 skill 正文：Human Writer 本地 skill `product-check` 的 `SKILL.md`，由 Claude 撰写，专为成品自查槽位写成。如果契约和本说明与 skill 正文冲突，以契约为准，其次以本说明为准。

## 交付方式

skill 正文写的是方法，产出按契约写成暂存目录下的 `review.json`：

| skill 正文里 | 在 `review.json` 里 |
| --- | --- |
| 每一条意见 | `issues` 里的一条，按在成品中出现的先后编 `no` |
| 失真 / 版面 / 正文问题 | `kind`：`fidelity` / `layout` / `content` |
| 位置 | `where` |
| 引文（正文原文） | `quote`，`fidelity` 和 `content` 必须有 |
| 问题、建议 | `problem`、`suggestion` |
| 总结 | `summary` |

“一、先列核对清单”是给自己用的，不写进产出。
