# 适配说明：report-check 用于 review 槽位

适配的 skill 正文：Human Writer 本地 skill `report-check` 的 `SKILL.md`，由 Claude 撰写，专为自查槽位写成。如果契约和本说明与 skill 正文冲突，以契约为准，其次以本说明为准。

## 输入

使用契约列出的全部输入：写作要求 `in/requirements.md`、选题 `in/brief.md`、框架 `in/outline.md`、素材清单 `in/materials.json`。素材按清单里的路径从素材目录读，只读不改。投递里没有的就跳过，不去作品目录找。

## 交付方式

skill 正文写的是方法，产出按契约写成暂存目录下的 `review.json`：

| skill 正文里 | 在 `review.json` 里 |
| --- | --- |
| 每一条问题 | `issues` 里的一条，按问题在正文中出现的先后编 `no` |
| 依据（标准、保持项编号，或素材路径） | `basis` |
| 合并同因时列出的其他位置 | 写在 `problem` 里，`quote` 只引一处 |
| 整体判断和每条标准的判断 | `summary`，写法按契约第 10 条 |

`quote` 按契约第 4 条：逐字复制，在正文里唯一，尽量短。
