# 适配说明：report-check 用于 review 槽位

适配的 skill 正文：Human Writer 本地 skill `report-check` 的 `SKILL.md`，由 Claude 撰写，专为自查槽位写成。如果契约和本说明与 skill 正文冲突，以契约为准，其次以本说明为准。

## 输入

使用契约列出的全部可选输入：上一版 `in/previous.md`、本轮修订依据 `round`、写作要求 `in/requirements.md`、选题 `in/brief.md`、框架 `in/outline.md`、素材清单 `in/materials.json`。素材按清单里的路径从素材目录读，只读不改。投递里没有的就跳过，不去作品目录找。

## 交付方式

skill 正文写的是方法，产出按契约写成暂存目录下的 `review.json`：

| skill 正文里 | 在 `review.json` 里 |
| --- | --- |
| 每一条问题 | `issues` 里的一条，按问题在正文中出现的先后编 `no` |
| 依据（目标、保持项、标准编号，或素材路径） | `basis` |
| 合并同因时列出的其他位置 | 写在 `problem` 里，`quote` 只引一处 |
| 第一句对照结果 | 没有本轮依据时写在 `summary` 开头；有本轮依据时不写，插件从 `followups` 和 `origin` 算出来，`summary` 按契约第 12 条 |
| "0 前后比较"的每一条退化或冗余 | `issues` 里的一条，`origin` 写 `introduced`，写法按契约第 10 条；`basis` 照常写依据，不写"上一版" |
| 有上一版时每一条问题的来历 | `origin`，按契约第 10 条 |
| "1 本轮依据"每一项的结果 | `followups` 里的一条；未解决的另报一条意见，`follows` 指向它，按契约第 11 条 |
| 和本轮依据方向相反的修改方向 | `reverses`，按契约第 11 条第 7 款 |

`quote` 按契约第 4 条：逐字复制，在正文里唯一，尽量短。
