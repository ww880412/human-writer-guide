# 适配说明：pyramid-long-form 用于 outline 槽位

适配的 skill 正文：`tyroneross/pyramid-principle` `ad50dcdbc00462181ee79d3ad48f18921ca75112` 的 `skills/pyramid-long-form/SKILL.md`。如果契约和本说明与 skill 正文冲突，以契约为准，其次以本说明为准。

这个 skill 是英文写的，按金字塔原理搭长文档的结构。在这里只用它搭框架的方法，产出用中文，格式按契约。

## 用哪些部分

- "Identify the Inputs"：读者的问题取自选题的"要回答的问题"，核心论点（governing thought）取自选题的"目的"和已知结论。
- "Build the Architecture" 的第 1 到 7 步。
- "Verify Before Returning" 的第 1、2、5、6、8 条。

## 深度固定为 Outline

skill 支持 outline、detailed outline、section draft、full document 四种深度。这里永远是 outline：只出框架，不写正文段落，不问作者要哪种深度。

## 格式的对应

| skill 里的说法 | 写进 `outline.md` 的位置 |
| --- | --- |
| 标题 | `# <材料标题>` |
| 核心论点（decision sentence） | 标题下的那一句话 |
| 断言式的节标题（asserted section heading） | `## <节标题>`，写成中文的判断句 |
| 节下的支撑（supports） | `要点：` 下的各项 |
| 支撑所依据的证据 | `素材：` 下的 `[已有]` 项 |
| Evidence limits | 不单独成节。缺的证据写成相应节的 `[待补]` 项 |

不打印 SCQA、key line、Governing Thought 这类英文标签。

## 不使用的部分

| skill 原来的做法 | 在这里 |
| --- | --- |
| 转交 `pyramid-short-form`、`pyramid-presentation`、`pyramid-audit` 等其他 skill | 不转交。短材料也照常出框架 |
| `pyramid-source-integrity` 的核查交接、strict trace 模式、claim ID | 不使用。素材是否真实存在，由契约的 `[已有]` 规则和插件的检查负责 |
| 读取 `references/` 和 `${CLAUDE_PLUGIN_ROOT}` 下的文件 | 不读取，这些文件不在投递里 |
| 缺信息时向作者提问 | 不提问。按选题和素材搭框架，缺的素材标 `[待补]` |
| 没有素材支撑就不建 Introduction、Next Steps 等节 | 保留这条原则。但选题的"要回答的问题"里要求的节（例如下一步计划），照常建，所需素材标 `[待补]` |
