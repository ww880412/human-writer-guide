# 适配说明：deck-story 用于 deck-plan 槽位

适配的 skill 正文：Human Writer 本地 skill `deck-story` 的 `SKILL.md`，由 Claude 撰写，专为第二层页面线写成。如果契约和本说明与 skill 正文冲突，以契约为准，其次以本说明为准。

这个槽位只出页纲，用 skill 正文的“一、归纳主线”“二、分页”“三、逐页压缩”“四、呈现方式”。“五、页面设计”“六、HTML 与 PPTX”不在这一步用。

skill 正文写的是方法；页纲的格式（主线、每页三项、去向表）、写到哪里、什么时候提交，都按契约。
