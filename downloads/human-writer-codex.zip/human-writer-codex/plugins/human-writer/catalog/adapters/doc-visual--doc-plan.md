# 适配说明：doc-visual 用于 doc-plan 槽位

适配的 skill 正文：Human Writer 本地 skill `doc-visual` 的 `SKILL.md`，由 Claude 撰写，专为第二层 Word 线写成。如果契约和本说明与 skill 正文冲突，以契约为准，其次以本说明为准。

这个槽位只出图文方案，用 skill 正文的“一、挑哪几处”和“二、图文方案怎么写”。“三、一张图怎么画”只用来判断一处内容能不能画好，不在这一步画图；“四、合成 Word”不用。

skill 正文写的是方法；输入从哪里读、方案写成什么格式、写到哪里、什么时候提交，都按契约。
