# Source

Repository: https://github.com/tyroneross/pyramid-principle
Commit: ad50dcdbc00462181ee79d3ad48f18921ca75112
Path: skills/pyramid-long-form/SKILL.md
Retrieved: 2026-10-08
