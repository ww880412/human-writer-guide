# dbs-ai-check

Repository: https://github.com/dontbesilent2025/dbskill
Commit: 3109543e23f2d68421bbb4974e78045b94a4563b
Path: skills/dbs-ai-check/SKILL.md
Retrieved: 2026-10-07
SHA-256: 15515598528b6d98ae489cf8add3a9f797a76aafa81994f92ce6e1ff6f7f0b8b
License: CC-BY-NC-4.0
