# Source

Repository: https://github.com/xstongxue/best-skills
Commit: 9aa4e555950da6e43e7d98c5f0c7b70264204850
Path: skills/md-report-summary/SKILL.md
Retrieved: 2026-10-08
