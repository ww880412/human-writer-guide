# 来源

Claude 撰写。

源文件：`docs/tasks/HW-24-texts/skills/deck-story/SKILL.md`

日期：2026-10-22
