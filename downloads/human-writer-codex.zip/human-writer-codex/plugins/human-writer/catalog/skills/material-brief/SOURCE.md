# Source

Claude 撰写。
源文件：docs/tasks/HW-06-texts/skills/material-brief/SKILL.md
日期：2026-10-08
