# 来源

Claude 撰写。

源文件：`docs/tasks/HW-14-texts/skills/doc-visual/SKILL.md`

日期：2026-10-11
