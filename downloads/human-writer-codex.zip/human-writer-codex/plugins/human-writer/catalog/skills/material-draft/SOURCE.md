# material-draft

Claude 撰写。

源文件：`docs/tasks/HW-09-texts/skills/material-draft/SKILL.md`

日期：2026-10-09。
