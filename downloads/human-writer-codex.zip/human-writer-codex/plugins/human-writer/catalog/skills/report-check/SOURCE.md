# report-check

Claude Opus 5.5 撰写。

源文件：`docs/tasks/HW-18-texts/skills/report-check/SKILL.md`

日期：2026-10-19。
