# Third-party notices

Human Writer 0.2.0 preserves the following upstream skill snapshots. Each component retains its own license. This package is not licensed as a whole under MIT. In particular, dbs-ai-check carries a non-commercial restriction. Local orchestration and local skills have no additional public license grant in this release.

## dbs-ai-check

- Source: https://github.com/dontbesilent2025/dbskill
- Commit: `3109543e23f2d68421bbb4974e78045b94a4563b`
- Original path: `skills/dbs-ai-check/SKILL.md`
- License: CC-BY-NC-4.0; see `catalog/skills/dbs-ai-check/LICENSE`.
- Original SKILL.md bytes are unchanged. Human Writer adds a separate adapter in `catalog/adapters/`.

## humanizer-zh

- Source: https://github.com/op7418/Humanizer-zh
- Commit: `f4518a8eab97b8bfebc66a89d34320a89bef6930`
- Original path: `SKILL.md`
- License: MIT; see `catalog/skills/humanizer-zh/LICENSE`.
- Original SKILL.md bytes are unchanged. Human Writer adds a separate adapter in `catalog/adapters/`.

## pyramid-long-form

- Source: https://github.com/tyroneross/pyramid-principle
- Commit: `ad50dcdbc00462181ee79d3ad48f18921ca75112`
- Original path: `skills/pyramid-long-form/SKILL.md`
- License: Apache-2.0; see `catalog/skills/pyramid-long-form/LICENSE`.
- Original SKILL.md bytes are unchanged. Human Writer adds a separate adapter in `catalog/adapters/`.

## md-report-summary

- Source: https://github.com/xstongxue/best-skills
- Commit: `9aa4e555950da6e43e7d98c5f0c7b70264204850`
- Original path: `skills/md-report-summary/SKILL.md`
- License: Apache-2.0; see `catalog/skills/md-report-summary/LICENSE`.
- Original SKILL.md bytes are unchanged. Human Writer adds a separate adapter in `catalog/adapters/`.

## Task State SDK

Bundled immutable snapshot from the same author’s Matt Pocock project, version 0.5.0, commit `5cce5bae103ab194b2b94ed58aecf0a2ccb84c80`. See `sdk-dependency.json` and `vendor/task-state-sdk/SDK-MANIFEST.json` for provenance and hashes. No broader third-party license is asserted here.
