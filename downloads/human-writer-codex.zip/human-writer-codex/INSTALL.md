# Install / update Human Writer 0.2.0

This package is for Codex. Tested: macOS, Node 24.13.0, Codex CLI 0.160.1. Other hosts are not supported by this package. Do not install individual writing skills globally.

## Before changes

1. Verify the ZIP's `.sha256`, then run `shasum -a 256 -c SHA256SUMS` from the extracted package root.
2. Read `plugins/human-writer/THIRD_PARTY_NOTICES.md`; dbs-ai-check has a non-commercial restriction.
3. Back up the effective Codex `config.toml`, existing Human Writer plugin cache and marketplace registration outside this public package, record SHA-256, and keep backup permissions private. Do not print secrets. Respect `CODEX_HOME` if set.
4. Check for an existing Human Writer installation. Reuse `human-writer@human-writer-local`; do not enable a second copy. Keep the extracted package directory in a persistent location.

## Install

From the package root, after user authorization:

```sh
codex plugin marketplace add "$PWD" --json
codex plugin add human-writer@human-writer-local --json
node scripts/trust-hooks.mjs --review
```

If `codex` is not in PATH, locate the Desktop-bundled CLI and pass its absolute path to `--codex`. The helper lists actual plugin hook definitions, purposes, hashes and a review token; it runs no model turn. Only after the user agrees to these two hooks:

```sh
node scripts/trust-hooks.mjs --approve <reviewToken>
```

Existing authorization to install/update and trust these same two Human Writer hooks is sufficient; do not ask again. The helper refuses duplicates, unexpected hook definitions, or changed review tokens. It edits only the two Human Writer hook trust records through Codex's configuration API. It does not change model, global tool approvals, or other plugin settings.

## Verify

Use a fresh Codex app-server/session to verify that `human-writer:human-writer` is enabled from version 0.2.0, both hooks are trusted, the MCP exposes its 9 production tools, and the installed files match this package. No daily `probe-enabled` marker is permitted. Recognize `$human-writer new <题目>` without creating a real work for installation testing. Open a new Desktop conversation for the updated entry skill; do not restart the user's ongoing conversation silently.

Compare configuration before/after with only the Human Writer plugin and its two hook records excluded. All other values must stay unchanged. Record verification, exact backup paths and hashes privately.

## Update / rollback / uninstall

Updates follow the same process using a verified new package. If `human-writer-local` is already registered from a different directory, save the old source, run `codex plugin marketplace remove human-writer-local --json`, then immediately register the new directory and install. This only replaces this marketplace registration; never remove other marketplaces. If registration/install fails, register the saved old source and restore the backed-up package. Never delete works or state. To roll back, restore the saved old package to a persistent directory, register/install it, and recheck only its actual hook hashes. Restore only Human Writer configuration fields if other settings have changed since backup; do not overwrite an entire newer config. Stop if old code cannot read the current state format.

Uninstall with `codex plugin remove human-writer@human-writer-local`, then remove only confirmed Human Writer hook trust entries if still present. This does not authorize deletion of works or SDK state. Marketplace removal is optional if no other package uses it.

State is under `$HOME/.local/state/human-writer/v1/sdk` and requires hard-link support. Imported sources are read-only; edited copies are under each project's `works/<slug>/`. See `docs/site/guide.html` and `architecture.html` for file-protection limits.
