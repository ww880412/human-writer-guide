# Human Writer 0.2.0

Codex 写作插件：从题目或已有稿件开始，按素材写稿、按意见润色，由作者确认框架、采纳意见和定稿。

- [发布页](https://ww880412.github.io/human-writer-guide/)
- [使用指南](https://ww880412.github.io/human-writer-guide/guide.html)
- [架构与验证边界](https://ww880412.github.io/human-writer-guide/architecture.html)
- 发布 ZIP 内 `docs/site/` 为同版离线指南，`INSTALL.md` 为安装、更新与回退步骤。

## 开始

在 Codex 中打开材料专用目录，输入 `$human-writer new <题目>`，或 `$human-writer import <项目内文件路径>`。随后说“用 Human Writer 处理当前作品”。

素材放在 `works/<slug>/materials/`，正文是 `works/<slug>/draft.md`。源稿只读，素材归作者所有。框架、采纳、候选处理和定稿由作者在原生卡片中回答。卡片不见时，告诉 agent 恢复当前问题。

`$human-writer open <作品>` 打开或接管；`$human-writer go <阶段>` 跳转；`$human-writer skills` 查目录；`$human-writer end` 结束本会话绑定，不删除作品。

## 能力与验证

可用阶段：选题、框架、写稿、自查、润色；定稿是作者关卡。7 个技能中，5 个选题/框架/写稿组合处于试用。配图、排版、二次发布尚未实现。

HW-06 工程验收：283/283 组件测试，9 个隔离宿主样本与 E5/E6 路线已核对。仅证明对应测试范围，不保证所有文章的质量。已验证环境：macOS、Node 24.13.0、Codex CLI 0.160.1。Desktop 菜单插入、重启细节和特定编辑器行为留待实际使用观察。

## 安装与状态

在源码或发布包根目录执行：

```sh
codex plugin marketplace add "$PWD" --json
codex plugin add human-writer@human-writer-local --json
```

安装/更新前备份配置与当前包，只调整 Human Writer 相关项。核对并授权 SessionStart、UserPromptSubmit 两个 hook 的实际定义和 hash；不要信任其他插件的 hook。新会话加载更新后的入口。

状态根固定为 `$HOME/.local/state/human-writer/v1/sdk`，所在文件系统必须支持硬链接。MCP 使用会话绑定的项目，不依赖自己的 cwd。日常安装不得放置 `probe-enabled` 标记。

## 文件保护的边界

作者保存与插件提交并发时，先移开工作文件再核对内容；正文冲突进入候选处理，选题/框架冲突把模型结果写入 `.new.md`。崩溃恢复沿同一判定重放。

编辑器持有旧文件描述符时，作者内容可能写在移开文件中；检查目标不存在与改名之间仍有极窄竞争窗口。保留版本和文件可帮助恢复，不等于绝对无丢失或完整备份。编辑器未重新加载时，保存也可能覆盖刚生成的新稿。

作品状态本机保存不表示模型处理离线：agent 读取的材料会进入所用模型的上下文。各组件许可见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)，其中 dbs-ai-check 含非商业限制。
