# Human Writer · Codex 0.4.2

从题目或已有稿件开始，整理框架、写稿、自查和修订；定稿后可继续制作 Word 或演示。作品、版本和作者要求保存在项目目录中。

## 开始使用

安装方法见包内 [INSTALL.md](INSTALL.md)，或[在线安装指南](https://ww880412.github.io/human-writer-guide/guide.html#install)。安装后打开新的 Codex 聊天，输入 `$human-writer`，选择新建或打开作品。已有稿件可用 `$human-writer import <项目内文本路径>` 导入。

先确认本篇标准。默认一次自查、有意见时修改一次，然后交稿等待作者；需要再审可主动发起。定稿、修改范围、框架和成品方案由作者决定。

## 技能与验证状态

| 当前状态 | 技能 | 证据边界 |
| --- | --- | --- |
| 样本验收通过 | material-brief、material-outline、material-draft、report-check、dbs-ai-check、humanizer-zh、doc-visual、deck-story、product-check | 当前组合的指定样本已通过内容验收；不保证真实写作质量稳定 |
| 暂不可用，待补验 | pyramid-long-form、md-report-summary | 契约更新后旧验收记录失效；补验前不能用于对应阶段 |

实际可用性可用 `$human-writer skills` 查看。隔离宿主样本中，作者答复由脚本提供，不等于真实作者使用。Word 与演示已核对指定成品样本；原生 Office、真实作者使用、外部工具接包和 Desktop 完全退出重启恢复仍有未验证范围。

## 文件与许可

原稿和素材归作者所有。作者编辑与模型提交冲突时保留作者内容，模型产物转为候选或另存文件；版本保护不能替代备份。Word 或演示中的改动不会自动回写正文。

本机保存不代表模型处理离线：模型读取的材料会进入所用模型上下文。[使用与文件保护指南](https://ww880412.github.io/human-writer-guide/guide.html)和[各组件许可](https://ww880412.github.io/human-writer-guide/guide.html#sources)分别说明这些边界；dbs-ai-check 的 CC BY-NC 4.0 含非商业限制。

本发布包保留运行必需的验收登记和许可证，排除内部样本、作者作品、个人使用记录与宿主配置。页面教学示例独立虚构，不作为验收证据。
