# Human Writer 0.3.2

Codex 写作插件：从题目或已有稿件开始，按素材写稿、按意见润色，由作者确认框架、采纳意见和定稿。

- [发布页](https://ww880412.github.io/human-writer-guide/)
- [使用指南](https://ww880412.github.io/human-writer-guide/guide.html)
- [架构与验证边界](https://ww880412.github.io/human-writer-guide/architecture.html)
- 安装包内 `docs/site/` 提供 0.3.2 离线指南，本次更新见下文，`INSTALL.md` 为安装、更新与回退步骤。

## 0.3.2 维护更新

- 裸入口与 status 展示写作路线、每步 skill 和当前位置，增加六个有名字的入口。
- 成品自查增加取舍、设计、渲染三层意见；需要改方案的问题明确标注。
- 作者要求“记个反馈”时，在项目根目录追加脱敏的反馈记录，累计五条提醒交给维护者。

本次公开发布 Codex 0.3.2。两种本机模式组件测试各 549/549；product-check 的 t5、t6 各执行和提交一次，检查器通过，保持试用。两份原始意见待 Claude 独立判读；隔离环境的中文与 HTML 渲染受限，完整视觉核验和真实使用效果未验证。

## 0.3.1 维护更新

- 识别原生决策卡答复标签外的首尾空白；重复收取仍只记录一次。
- 自查补充案例可比性、团队判断与个人归因、措施对应关系；修订后也检查相关论证。
- 按成品契约允许有来源的水平零起点 SVG 线性轴刻度；业务数字仍检查来源。

该版本组件回归两种本机模式各 549/549，五个隔离宿主样本提交通过。David 已完成真实答卡及同一聊天后续核对，只推进一次；Desktop 完全退出重启恢复仍未验证，已按 David 决定暂缓。

## 开始

在 Codex 中打开材料专用目录，输入 `$human-writer new <题目>`，或 `$human-writer import <项目内文件路径>`。随后说“用 Human Writer 处理当前作品”。

素材放在 `works/<slug>/materials/`，正文是 `works/<slug>/draft.md`。源稿只读，素材归作者所有。框架、采纳、候选处理和定稿由作者在原生卡片中回答。卡片不见时，告诉 agent 恢复当前问题。

`$human-writer open <作品>` 打开或接管；`$human-writer go <阶段>` 跳转；`$human-writer skills` 查目录；`$human-writer end` 结束本会话绑定，不删除作品。

## 能力与验证

已实现阶段：选题、框架、写稿、自查、润色；定稿是作者关卡。目录含 11 个技能，当前可用性与试用状态以 `$human-writer skills` 为准。定稿后可继续生成 Word、HTML 演示与可编辑 PPTX。公众号排版、独立配图/排版及二次发布槽位尚未开放。

## 写作要求与 Word 稿

可在 `works/<slug>/requirements.md` 写适用标准、必须保持的内容和本轮目标，建议分别用 S、K、G 编号。它归作者所有；作者自己修改，或明确要求模型代写并查看全文。插件只读，在写稿、自查与润色开始时冻结当时版本；修改确认轮次使用开卡时已经冻结的版本。目标只有被作者的修改要求点名时才进入修订范围。

导入只接受 UTF-8 文本。Word 稿先转成 Markdown 再导入，原 DOCX 可放进 `materials/` 留作来源。作品打开期间，插件版本链是正文的权威。在导出的 Word 里修改后，先停下流程，把修改后的 Word 转回 Markdown 覆盖 `draft.md`，登记作者编辑后再继续；模型代办转换和覆盖需要作者明确要求。已定稿作品要继续修订，可以直接说明修改要求；要先自查，可输入 `go review`。不要用旧正文重新生成 Word 覆盖手改文件；定稿后说“做成 Word”或“做成演示”，插件会先出方案，作者确认后再制作、自查和交付。成品手改会被保留，新产物另存 `.new`；正文仍以 Markdown 为正本，不自动将成品修改回写正文。

## 按要求修订已有稿

直接说要怎么改，例如“按刚才的三条意见改这份”。插件会开一张修改确认卡，列出修改原话；作者在卡上选择“修改（可以补内容、改判断）”“只改措辞”或“先不改”。已有卡片或正在等待本轮要求时，先按当前提示处理。

必须逐字保留的原文，在 `requirements.md` 的 K 条目里用「」标出，标点和空格也照原文复制。修订会检查基准稿中存在的引文；基准稿中没有的引文会列为跳过。采纳的自查意见含事实或论证类时，流程进入写稿修订；全部为表达类时进入润色。

修订之后的自查会和修订前的版本比较，报出这一轮丢掉或改弱的内容（依据写“上一版”）。要按新思路重组整篇时，先把主线记进写作要求的“必须保持”，再输入 `$human-writer go outline`（还没有选题时用 `go topic`），确认框架后插件会按框架重组现稿，并逐节写明原有内容去了哪里。

HW-14 已通过独立验收：两种模式组件测试各 545/545，五个成品组合样本和一次连续 Codex 冒烟已核对。样本及脚本作答属于 H-synthetic，不等于真实作者效果。已验证环境：macOS、Node 24.13.0、Codex CLI 0.162.0-alpha.17.2。HTML 因沙箱未逐页渲染时会明确说明，打开后仍需留意版面。

## 安装与状态

在源码或发布包根目录执行：

```sh
codex plugin marketplace add "$PWD" --json
codex plugin add human-writer@human-writer-local --json
```

安装/更新前备份配置与当前包，只调整 Human Writer 相关项。核对并授权 SessionStart、UserPromptSubmit 两个 hook 的实际定义和 hash；不要信任其他插件的 hook。新会话加载更新后的入口。

状态根固定为 `$HOME/.local/state/human-writer/v1/sdk`，所在文件系统必须支持硬链接。MCP 使用会话绑定的项目，不依赖自己的 cwd。日常安装不得放置 `probe-enabled` 标记。

## 在 Claude Code 里用

从项目源码根目录构建 Claude 包（需要 Node 和 Git）：

```sh
node tools/build-human-writer-claude.mjs
```

输出为 `work/dist/claude/human-writer/`，构建会校验入口文本 SHA 和 SDK，并生成 `BUILD.json`。这是 Claude 独立包；真实宿主验证状态见 `docs/tasks/HW-10-host-results.md`（尚未生成时表示未交付宿主结果）。

Claude Code 在 VM 中运行时，下面的命令在 **VM 的终端**执行。先进入 VM 能看到的项目根目录，再启动：

```sh
claude --plugin-dir "$PWD/work/dist/claude/human-writer"
```

`$PWD` 是运行该命令的 VM 内路径；不要直接使用物理 Mac 的项目绝对路径。插件清单通过 `${CLAUDE_PLUGIN_ROOT}` 定位运行文件，不绑定用户名或挂载点。共享目录里的构建产物可以直接被 VM 使用，但 VM 内的可读性、登录状态和实际加载仍需在 VM 中验证。

入口为 `/human-writer`（也支持 `/human-writer:human-writer`）。作者在插件弹出的表单里回答关卡；关闭表单不算回答，想回答时告诉模型重新弹出。采纳卡的选项和编号两栏只填一栏。不要使用 Codex 的 `bind`、`collect` 操作。

上面的 `--plugin-dir` 是本次启动的加载方式；是否安装到日常 Claude 配置，由作者另行决定。HW-10 隔离实测应遵循任务书 §2.4，由 VM 内的 Claude 执行，不能把这条启动命令当成隔离实测。

## 文件保护的边界

作者保存与插件提交并发时，先移开工作文件再核对内容；正文冲突进入候选处理，选题/框架冲突把模型结果写入 `.new.md`。崩溃恢复沿同一判定重放。

编辑器持有旧文件描述符时，作者内容可能写在移开文件中；检查目标不存在与改名之间仍有极窄竞争窗口。保留版本和文件可帮助恢复，不等于绝对无丢失或完整备份。编辑器未重新加载时，保存也可能覆盖刚生成的新稿。

作品状态本机保存不表示模型处理离线：agent 读取的材料会进入所用模型的上下文。各组件许可见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)，其中 dbs-ai-check 含非商业限制。
